package org.cap.dao;

import java.util.List;

import org.cap.model.Pilot;


public interface IPilotDao {

	public void savePilot(Pilot pilot);
	public List<Pilot> getAllPilots();
	public void deletePilot(Integer pilotId);
	public List<Pilot> getPilot(Integer pilotId);
}
