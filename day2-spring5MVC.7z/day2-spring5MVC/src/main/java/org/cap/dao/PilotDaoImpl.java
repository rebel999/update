package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;

@Repository("PilotDao")
@Transactional
public class PilotDaoImpl implements IPilotDao {

	@PersistenceContext
	private EntityManager em;
	
	
	@Override
	public void savePilot(Pilot pilot) {
		em.persist(pilot);
	}

	@Override
	public List<Pilot> getAllPilots() {
		@SuppressWarnings("unchecked")
		List<Pilot> pilot=em.createQuery("from Pilot").getResultList();
		return pilot;
	}

	@Override
	public void deletePilot(Integer pilotId) {
		
		Pilot pilot=em.find(Pilot.class, pilotId);
		if(pilot!=null)
		em.remove(pilot);
		
	}


	@Override
	public List<Pilot> getPilot(Integer pilotId) {
		
		@SuppressWarnings("unchecked")
		List<Pilot> pilot=em.createQuery("from Pilot where pilotId="+pilotId).getResultList();
		
		return pilot;
	}

	
}
